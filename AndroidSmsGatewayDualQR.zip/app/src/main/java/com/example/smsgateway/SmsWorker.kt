package com.example.smsgateway

import android.content.Context
import android.telephony.SmsManager
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class SmsWorker(appContext: Context, params: WorkerParameters): CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val prefs = applicationContext.getSharedPreferences("gateway", Context.MODE_PRIVATE)
        val serverUrl = prefs.getString("server_url", "")!!.trim().removeSuffix("/")
        val apiKey = prefs.getString("api_key", "")!!.trim()
        val subId = prefs.getInt("sub_id", -1)

        if (serverUrl.isEmpty() || apiKey.isEmpty()) {
            Log.e("SmsWorker", "Missing server URL or API key")
            return@withContext Result.failure()
        }

        return@withContext try {
            val queueUrl = "$serverUrl/api/queue.php?api_key=$apiKey&device_number=" + URLEncoder.encode("", "UTF-8")
            val queueResp = URL(queueUrl).readText()
            val data = JSONObject(queueResp)

            if (!data.optBoolean("ok")) {
                Log.w("SmsWorker", "Server returned not ok")
                Result.retry()
            } else {
                val messages = data.getJSONArray("messages")
                val smsManager: SmsManager = if (subId != -1) {
                    try { SmsManager.getSmsManagerForSubscriptionId(subId) } catch (_: Exception) { SmsManager.getDefault() }
                } else {
                    SmsManager.getDefault()
                }
                for (i in 0 until messages.length()) {
                    val msg = messages.getJSONObject(i)
                    val id = msg.getLong("id")
                    val to = msg.getString("to_number")
                    val body = msg.getString("body")
                    try {
                        val parts = smsManager.divideMessage(body)
                        smsManager.sendMultipartTextMessage(to, null, parts, null, null)
                        postStatus(serverUrl, apiKey, id, "sent", null)
                    } catch (e: Exception) {
                        postStatus(serverUrl, apiKey, id, "failed", e.message)
                    }
                }
                Result.success()
            }
        } catch (e: Exception) {
            Log.e("SmsWorker", "Error: ${e.message}", e)
            Result.retry()
        }
    }

    private fun postStatus(serverUrl: String, apiKey: String, id: Long, status: String, error: String?) {
        try {
            val json = JSONObject()
            json.put("api_key", apiKey)
            json.put("id", id)
            json.put("status", status)
            if (error != null) json.put("error", error)

            val url = URL("$serverUrl/api/update_status.php")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                connectTimeout = 15000
                readTimeout = 15000
            }
            OutputStreamWriter(conn.outputStream).use { it.write(json.toString()) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = BufferedReader(InputStreamReader(conn.errorStream ?: conn.inputStream)).readText()
                Log.w("SmsWorker", "Post status HTTP $code: $err")
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.e("SmsWorker", "postStatus error: ${e.message}", e)
        }
    }

    companion object {
        fun enqueueNow(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<SmsWorker>().build()
            WorkManager.getInstance(ctx).enqueue(req)
        }
    }
}
