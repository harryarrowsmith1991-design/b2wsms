package com.example.smsgateway

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var inputServerUrl: EditText
    private lateinit var inputApiKey: EditText
    private lateinit var spinnerSim: Spinner
    private lateinit var txtStatus: TextView

    private var subs: List<SubscriptionInfo> = emptyList()
    private var selectedSubId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputServerUrl = findViewById(R.id.inputServerUrl)
        inputApiKey = findViewById(R.id.inputApiKey)
        spinnerSim = findViewById(R.id.spinnerSim)
        txtStatus = findViewById(R.id.txtStatus)

        val prefs = getSharedPreferences("gateway", MODE_PRIVATE)
        inputServerUrl.setText(prefs.getString("server_url", "https://sms.mafia-assassins.co.uk"))
        inputApiKey.setText(prefs.getString("api_key", ""))
        selectedSubId = prefs.getInt("sub_id", -1)

        // Buttons
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            prefs.edit()
                .putString("server_url", inputServerUrl.text.toString().trim())
                .putString("api_key", inputApiKey.text.toString().trim())
                .putInt("sub_id", selectedSubId)
                .apply()
            txtStatus.text = "Saved settings."
            scheduleWorker()
        }
        findViewById<Button>(R.id.btnRunNow).setOnClickListener { SmsWorker.enqueueNow(this) }
        findViewById<Button>(R.id.btnScan).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 2001)
            } else {
                startActivityForResult(Intent(this, ScannerActivity::class.java), 3001)
            }
        }

        ensurePermissions()
        loadSubscriptions()
        scheduleWorker()
    }

    private fun ensurePermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.SEND_SMS)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.READ_PHONE_STATE)
        if (needed.isNotEmpty())
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 1234)
    }

    private fun loadSubscriptions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            spinnerSim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Default SIM"))
            selectedSubId = -1
            return
        }
        val sm = getSystemService(SubscriptionManager::class.java)
        subs = sm.activeSubscriptionInfoList ?: emptyList()
        val labels = if (subs.isEmpty()) listOf("Default SIM") else subs.map { s ->
            val name = s.displayName?.toString() ?: "SIM"
            val num = s.number ?: ""
            "$name ${if (num.isNotEmpty()) "($num)" else ""}"
        }
        spinnerSim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        // Preselect saved subId
        if (selectedSubId != -1) {
            val idx = subs.indexOfFirst { it.subscriptionId == selectedSubId }
            if (idx >= 0) spinnerSim.setSelection(idx)
        }
        spinnerSim.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedSubId = if (subs.isEmpty()) -1 else subs[position].subscriptionId
            }
            override fun onNothingSelected(parent: AdapterView<*>?) { }
        }
    }

    private fun scheduleWorker() {
        val work = PeriodicWorkRequestBuilder<SmsWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "sms_worker",
            ExistingPeriodicWorkPolicy.KEEP,
            work
        )
        txtStatus.text = "Worker scheduled (polls ~every 15 minutes)."
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 3001 && resultCode == RESULT_OK && data != null) {
            val qr = data.getStringExtra("qr") ?: return
            // Accept "api_key=...&server=https://..." or JSON {"api_key":"...","server":"..."}
            var api = ""
            var server = ""
            if (qr.trim().startsWith("{")) {
                try {
                    val obj = org.json.JSONObject(qr)
                    api = obj.optString("api_key", "")
                    server = obj.optString("server", "")
                } catch (_: Exception) {}
            } else {
                qr.split("&").forEach {
                    val kv = it.split("=", limit = 2)
                    if (kv.size == 2) {
                        if (kv[0] == "api_key") api = kv[1]
                        if (kv[0] == "server") server = kv[1]
                    }
                }
            }
            if (server.isNotBlank()) inputServerUrl.setText(server)
            if (api.isNotBlank()) inputApiKey.setText(api)
            Toast.makeText(this, "QR applied.", Toast.LENGTH_SHORT).show()
        }
    }
}
